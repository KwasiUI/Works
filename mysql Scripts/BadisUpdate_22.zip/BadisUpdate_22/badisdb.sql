-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2021 at 10:47 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `badisdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblbudget`
--

CREATE TABLE `tblbudget` (
  `BudgetID` int(11) NOT NULL,
  `FYSectorID` int(11) NOT NULL,
  `ProjectID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `DSIPBudgetAmount` double NOT NULL,
  `GoPNGBudgetAmount` double NOT NULL,
  `DSIPActualAmount` double NOT NULL,
  `GoPNGActualAmount` double NOT NULL,
  `DSIPActualBalance` double NOT NULL,
  `GoPNGActualBalance` double NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `CategoryID` int(11) NOT NULL,
  `Category` varchar(80) NOT NULL,
  `CategoryCode` varchar(20) NOT NULL,
  `DistrictID` int(11) NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblclient`
--

CREATE TABLE `tblclient` (
  `ClientID` int(11) NOT NULL,
  `ClientName` varchar(30) NOT NULL,
  `ClientAddress` varchar(80) NOT NULL,
  `ClientPhone` varchar(30) DEFAULT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblddameeting`
--

CREATE TABLE `tblddameeting` (
  `DDAMeetingID` int(11) NOT NULL,
  `MeetingMinute` varchar(200) NOT NULL,
  `MeetingDate` date NOT NULL,
  `MeetingNo` varchar(20) NOT NULL,
  `MeetingVenue` varchar(20) NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbldecision`
--

CREATE TABLE `tbldecision` (
  `DecisionID` int(11) NOT NULL,
  `Decision` varchar(30) NOT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbldistrict`
--

CREATE TABLE `tbldistrict` (
  `DistrictID` int(11) NOT NULL,
  `DistrictName` varchar(80) NOT NULL,
  `DAName` varchar(20) NOT NULL,
  `ProvinceID` int(11) NOT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbldistrict`
--

INSERT INTO `tbldistrict` (`DistrictID`, `DistrictName`, `DAName`, `ProvinceID`, `TimeStamp`) VALUES
(1, 'Gumine', 'District Administrat', 1, '2020-10-03 05:47:03'),
(2, 'Kubaya', 'Afari Jesse', 1, '2021-05-22 06:37:34');

-- --------------------------------------------------------

--
-- Table structure for table `tblexpenditure`
--

CREATE TABLE `tblexpenditure` (
  `ExpenditureID` int(11) NOT NULL,
  `BudgetID` int(11) NOT NULL,
  `CheckNo` varchar(20) NOT NULL,
  `CheckDate` date NOT NULL,
  `CheckAmount` double NOT NULL,
  `SubmissionID` int(11) DEFAULT NULL,
  `RequisitionID` int(11) DEFAULT NULL,
  `ExpenseCode` varchar(20) DEFAULT NULL,
  `VoteCode` varchar(20) DEFAULT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblfinancialyear`
--

CREATE TABLE `tblfinancialyear` (
  `FYID` int(11) NOT NULL,
  `FinancialYear` int(11) NOT NULL,
  `Description` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `DistrictID` int(11) NOT NULL,
  `UserLogin` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblfinancialyear`
--

INSERT INTO `tblfinancialyear` (`FYID`, `FinancialYear`, `Description`, `DistrictID`, `UserLogin`, `TimeStamp`) VALUES
(1, 2020, '2020 Financial Year', 1, NULL, '2020-10-03 06:51:34'),
(2, 2020, '2020 Financial Year', 2, NULL, '2021-05-22 06:39:15'),
(3, 2021, '2021 Financial Year', 1, NULL, '2021-05-22 06:52:16');

-- --------------------------------------------------------

--
-- Table structure for table `tblfyearsector`
--

CREATE TABLE `tblfyearsector` (
  `FYSectorID` int(11) NOT NULL,
  `FYID` int(11) NOT NULL,
  `SectorID` int(11) NOT NULL,
  `DSIPBudgetAmount` double NOT NULL,
  `GoPNGBudgetAmount` double NOT NULL,
  `UserLogin` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `DistrictID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblfyearsector`
--

INSERT INTO `tblfyearsector` (`FYSectorID`, `FYID`, `SectorID`, `DSIPBudgetAmount`, `GoPNGBudgetAmount`, `UserLogin`, `TimeStamp`, `DistrictID`) VALUES
(5, 1, 2, 300000, 0, '', '2020-10-02 22:30:17', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblproject`
--

CREATE TABLE `tblproject` (
  `ProjectID` int(11) NOT NULL,
  `Project` varchar(80) NOT NULL,
  `ProjectCode` varchar(20) NOT NULL,
  `DistrictID` int(11) NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `SectorID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblprovince`
--

CREATE TABLE `tblprovince` (
  `ProvinceID` int(11) NOT NULL,
  `ProvinceName` varchar(80) NOT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblprovince`
--

INSERT INTO `tblprovince` (`ProvinceID`, `ProvinceName`, `TimeStamp`) VALUES
(1, 'Simbu', '2020-10-03 05:44:36');

-- --------------------------------------------------------

--
-- Table structure for table `tblquotation`
--

CREATE TABLE `tblquotation` (
  `QuotationID` int(11) NOT NULL,
  `Amount` double NOT NULL,
  `Remarks` varchar(200) DEFAULT NULL,
  `QuoteDoc` varchar(200) DEFAULT NULL,
  `EOIDoc` varchar(200) DEFAULT NULL,
  `ClientID` int(11) NOT NULL,
  `RequisitionID` int(11) NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblrequisition`
--

CREATE TABLE `tblrequisition` (
  `RequisitionID` int(11) NOT NULL,
  `Description` varchar(80) NOT NULL,
  `RequisitionDate` date NOT NULL,
  `BudgetID` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `RevenueTypeID` int(11) NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblrequisitionapproval`
--

CREATE TABLE `tblrequisitionapproval` (
  `ApproveDate` date NOT NULL,
  `DecisionID` int(11) NOT NULL,
  `Comment` varchar(80) DEFAULT NULL,
  `RequisitionID` int(11) NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblrevenue`
--

CREATE TABLE `tblrevenue` (
  `RevenueID` int(11) NOT NULL,
  `Reference` varchar(20) NOT NULL,
  `RevenueDate` date NOT NULL,
  `RevenueAmount` double NOT NULL,
  `RevenueTypeID` int(11) NOT NULL,
  `FYID` int(11) NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblrevenuedetail`
--

CREATE TABLE `tblrevenuedetail` (
  `RevenueDetailID` int(11) NOT NULL,
  `BudgetID` int(11) NOT NULL,
  `ProjectAmount` double NOT NULL,
  `RevenueID` int(11) NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblrevenuetype`
--

CREATE TABLE `tblrevenuetype` (
  `RevenueTypeID` int(11) NOT NULL,
  `RevenueType` varchar(30) NOT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblsector`
--

CREATE TABLE `tblsector` (
  `SectorID` int(11) NOT NULL,
  `Sector` varchar(80) CHARACTER SET utf8mb4 NOT NULL,
  `SectorCode` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `DistrictID` int(11) NOT NULL,
  `UserLogin` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblsector`
--

INSERT INTO `tblsector` (`SectorID`, `Sector`, `SectorCode`, `DistrictID`, `UserLogin`, `TimeStamp`) VALUES
(1, 'General Administration', '3-11-110-AdGA', 1, NULL, '2020-10-03 06:56:05'),
(2, 'Electoral (MP) Office Operational Support', '3-11-110-AdDP', 1, NULL, '2020-10-03 06:56:54'),
(3, 'Economic Sector Support', '3-11-110-Ec', 1, NULL, '2021-05-22 07:30:36'),
(4, 'Economic Sector Support', '3-11-110-Ec', 2, NULL, '2021-05-22 07:36:31');

-- --------------------------------------------------------

--
-- Table structure for table `tblstatus`
--

CREATE TABLE `tblstatus` (
  `StatusID` int(11) NOT NULL,
  `Status` varchar(30) NOT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblsubmission`
--

CREATE TABLE `tblsubmission` (
  `SubmissionID` int(11) NOT NULL,
  `Description` varchar(80) NOT NULL,
  `SubmissionDate` date NOT NULL,
  `ClientID` int(11) NOT NULL,
  `BudgetID` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `RevenueTypeID` int(11) NOT NULL,
  `DDAMeetingID` int(11) NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblsubmissionapproval`
--

CREATE TABLE `tblsubmissionapproval` (
  `ApproveDate` date NOT NULL,
  `DecisionID` int(11) NOT NULL,
  `Comment` varchar(80) DEFAULT NULL,
  `SubmissionID` int(11) NOT NULL,
  `UserLogin` varchar(20) DEFAULT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `UserID` varchar(20) NOT NULL,
  `FullName` varchar(30) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `DistrictID` int(11) NOT NULL,
  `FYID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`UserID`, `FullName`, `Password`, `DistrictID`, `FYID`) VALUES
('JesPort01', 'Jesse A', 'jess123', 2, 2),
('NickLae01', 'Nick Puy', 'nick123', 1, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vwdistrictfy`
-- (See below for the actual view)
--
CREATE TABLE `vwdistrictfy` (
`FYID` int(11)
,`DistrictID` int(11)
,`DNFY` varchar(92)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vwdistrictsector_lookup`
-- (See below for the actual view)
--
CREATE TABLE `vwdistrictsector_lookup` (
`SectorID` int(11)
,`DistrictID` int(11)
,`concat(DistrictName,"-",Sector)` varchar(161)
);

-- --------------------------------------------------------

--
-- Structure for view `vwdistrictfy`
--
DROP TABLE IF EXISTS `vwdistrictfy`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwdistrictfy`  AS  select `tblfinancialyear`.`FYID` AS `FYID`,`tbldistrict`.`DistrictID` AS `DistrictID`,concat(`tbldistrict`.`DistrictName`,'-',`tblfinancialyear`.`FinancialYear`) AS `DNFY` from (`tbldistrict` join `tblfinancialyear` on(`tbldistrict`.`DistrictID` = `tblfinancialyear`.`DistrictID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `vwdistrictsector_lookup`
--
DROP TABLE IF EXISTS `vwdistrictsector_lookup`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwdistrictsector_lookup`  AS  select `tblsector`.`SectorID` AS `SectorID`,`tbldistrict`.`DistrictID` AS `DistrictID`,concat(`tbldistrict`.`DistrictName`,'-',`tblsector`.`Sector`) AS `concat(DistrictName,"-",Sector)` from (`tbldistrict` join `tblsector` on(`tbldistrict`.`DistrictID` = `tblsector`.`DistrictID`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblbudget`
--
ALTER TABLE `tblbudget`
  ADD PRIMARY KEY (`ProjectID`,`FYSectorID`),
  ADD UNIQUE KEY `BudgetID` (`BudgetID`),
  ADD KEY `CategoryBudget_FK` (`CategoryID`),
  ADD KEY `FYearSectorBudget_FK` (`FYSectorID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`CategoryID`),
  ADD KEY `CategoryDistrict_FK` (`DistrictID`);

--
-- Indexes for table `tblclient`
--
ALTER TABLE `tblclient`
  ADD PRIMARY KEY (`ClientID`);

--
-- Indexes for table `tblddameeting`
--
ALTER TABLE `tblddameeting`
  ADD PRIMARY KEY (`DDAMeetingID`);

--
-- Indexes for table `tbldecision`
--
ALTER TABLE `tbldecision`
  ADD PRIMARY KEY (`DecisionID`);

--
-- Indexes for table `tbldistrict`
--
ALTER TABLE `tbldistrict`
  ADD PRIMARY KEY (`DistrictID`),
  ADD KEY `DistrictProvince_FK` (`ProvinceID`);

--
-- Indexes for table `tblexpenditure`
--
ALTER TABLE `tblexpenditure`
  ADD PRIMARY KEY (`ExpenditureID`),
  ADD KEY `ExpenditureRequisitionApproval_FK` (`RequisitionID`),
  ADD KEY `ExpenditureSubmissionApproval_FK` (`SubmissionID`);

--
-- Indexes for table `tblfinancialyear`
--
ALTER TABLE `tblfinancialyear`
  ADD PRIMARY KEY (`FYID`),
  ADD UNIQUE KEY `FinancialYearDistrictID_IDX` (`FinancialYear`,`DistrictID`),
  ADD KEY `FinancialYearDistrict_FK` (`DistrictID`);

--
-- Indexes for table `tblfyearsector`
--
ALTER TABLE `tblfyearsector`
  ADD PRIMARY KEY (`FYSectorID`),
  ADD KEY `SectorFinancialYear_FK` (`SectorID`),
  ADD KEY `RevenueDatailProject_FK` (`FYID`);

--
-- Indexes for table `tblproject`
--
ALTER TABLE `tblproject`
  ADD PRIMARY KEY (`ProjectID`),
  ADD KEY `ProjectDistrict_FK` (`DistrictID`);

--
-- Indexes for table `tblprovince`
--
ALTER TABLE `tblprovince`
  ADD PRIMARY KEY (`ProvinceID`);

--
-- Indexes for table `tblquotation`
--
ALTER TABLE `tblquotation`
  ADD PRIMARY KEY (`QuotationID`),
  ADD UNIQUE KEY `tblquotation_unique` (`ClientID`,`RequisitionID`),
  ADD KEY `QuotationRequisition_FK` (`RequisitionID`);

--
-- Indexes for table `tblrequisition`
--
ALTER TABLE `tblrequisition`
  ADD PRIMARY KEY (`RequisitionID`),
  ADD KEY `RequisitionStatus_FK` (`StatusID`),
  ADD KEY `RequisitionBudget_FK` (`BudgetID`),
  ADD KEY `RevenueTypeRequisition_FK` (`RevenueTypeID`);

--
-- Indexes for table `tblrequisitionapproval`
--
ALTER TABLE `tblrequisitionapproval`
  ADD PRIMARY KEY (`RequisitionID`),
  ADD KEY `RequisitionApprovalDecision_FK` (`DecisionID`);

--
-- Indexes for table `tblrevenue`
--
ALTER TABLE `tblrevenue`
  ADD PRIMARY KEY (`RevenueID`),
  ADD KEY `RevenueRevenueType_FK` (`RevenueTypeID`);

--
-- Indexes for table `tblrevenuedetail`
--
ALTER TABLE `tblrevenuedetail`
  ADD PRIMARY KEY (`RevenueDetailID`),
  ADD KEY `RevenueDatailRevenue_FK` (`RevenueID`),
  ADD KEY `BudgetRevenue_FK` (`BudgetID`);

--
-- Indexes for table `tblrevenuetype`
--
ALTER TABLE `tblrevenuetype`
  ADD PRIMARY KEY (`RevenueTypeID`);

--
-- Indexes for table `tblsector`
--
ALTER TABLE `tblsector`
  ADD PRIMARY KEY (`SectorID`),
  ADD KEY `SectorDistrict_FK` (`DistrictID`);

--
-- Indexes for table `tblstatus`
--
ALTER TABLE `tblstatus`
  ADD PRIMARY KEY (`StatusID`);

--
-- Indexes for table `tblsubmission`
--
ALTER TABLE `tblsubmission`
  ADD PRIMARY KEY (`SubmissionID`),
  ADD KEY `BudgetSubmission_FK` (`BudgetID`),
  ADD KEY `DDAMeetingSubmission_FK` (`DDAMeetingID`),
  ADD KEY `SubmissionStatus_FK` (`StatusID`),
  ADD KEY `RevenueTypeSubmission_FK` (`RevenueTypeID`);

--
-- Indexes for table `tblsubmissionapproval`
--
ALTER TABLE `tblsubmissionapproval`
  ADD PRIMARY KEY (`SubmissionID`),
  ADD KEY `SubmissionApprovalDecision_FK` (`DecisionID`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `DistrictUser_FK` (`DistrictID`),
  ADD KEY `FYearUser_FK` (`FYID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblbudget`
--
ALTER TABLE `tblbudget`
  MODIFY `BudgetID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `CategoryID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblclient`
--
ALTER TABLE `tblclient`
  MODIFY `ClientID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblddameeting`
--
ALTER TABLE `tblddameeting`
  MODIFY `DDAMeetingID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbldecision`
--
ALTER TABLE `tbldecision`
  MODIFY `DecisionID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbldistrict`
--
ALTER TABLE `tbldistrict`
  MODIFY `DistrictID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblexpenditure`
--
ALTER TABLE `tblexpenditure`
  MODIFY `ExpenditureID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblfinancialyear`
--
ALTER TABLE `tblfinancialyear`
  MODIFY `FYID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblfyearsector`
--
ALTER TABLE `tblfyearsector`
  MODIFY `FYSectorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblproject`
--
ALTER TABLE `tblproject`
  MODIFY `ProjectID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblprovince`
--
ALTER TABLE `tblprovince`
  MODIFY `ProvinceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblquotation`
--
ALTER TABLE `tblquotation`
  MODIFY `QuotationID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrequisition`
--
ALTER TABLE `tblrequisition`
  MODIFY `RequisitionID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrevenue`
--
ALTER TABLE `tblrevenue`
  MODIFY `RevenueID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrevenuedetail`
--
ALTER TABLE `tblrevenuedetail`
  MODIFY `RevenueDetailID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrevenuetype`
--
ALTER TABLE `tblrevenuetype`
  MODIFY `RevenueTypeID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblsector`
--
ALTER TABLE `tblsector`
  MODIFY `SectorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblstatus`
--
ALTER TABLE `tblstatus`
  MODIFY `StatusID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblsubmission`
--
ALTER TABLE `tblsubmission`
  MODIFY `SubmissionID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblbudget`
--
ALTER TABLE `tblbudget`
  ADD CONSTRAINT `CategoryBudget_FK` FOREIGN KEY (`CategoryID`) REFERENCES `tblcategory` (`CategoryID`),
  ADD CONSTRAINT `FYearSectorBudget_FK` FOREIGN KEY (`FYSectorID`) REFERENCES `tblfyearsector` (`FYSectorID`),
  ADD CONSTRAINT `ProjectBudget_FK` FOREIGN KEY (`ProjectID`) REFERENCES `tblproject` (`ProjectID`);

--
-- Constraints for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD CONSTRAINT `CategoryDistrict_FK` FOREIGN KEY (`DistrictID`) REFERENCES `tbldistrict` (`DistrictID`);

--
-- Constraints for table `tbldistrict`
--
ALTER TABLE `tbldistrict`
  ADD CONSTRAINT `DistrictProvince_FK` FOREIGN KEY (`ProvinceID`) REFERENCES `tblprovince` (`ProvinceID`);

--
-- Constraints for table `tblexpenditure`
--
ALTER TABLE `tblexpenditure`
  ADD CONSTRAINT `ExpenditureRequisitionApproval_FK` FOREIGN KEY (`RequisitionID`) REFERENCES `tblrequisitionapproval` (`RequisitionID`),
  ADD CONSTRAINT `ExpenditureSubmissionApproval_FK` FOREIGN KEY (`SubmissionID`) REFERENCES `tblsubmissionapproval` (`SubmissionID`);

--
-- Constraints for table `tblfinancialyear`
--
ALTER TABLE `tblfinancialyear`
  ADD CONSTRAINT `FinancialYearDistrict_FK` FOREIGN KEY (`DistrictID`) REFERENCES `tbldistrict` (`DistrictID`);

--
-- Constraints for table `tblfyearsector`
--
ALTER TABLE `tblfyearsector`
  ADD CONSTRAINT `RevenueDatailProject_FK` FOREIGN KEY (`FYID`) REFERENCES `tblfinancialyear` (`FYID`),
  ADD CONSTRAINT `SectorFinancialYear_FK` FOREIGN KEY (`SectorID`) REFERENCES `tblsector` (`SectorID`);

--
-- Constraints for table `tblproject`
--
ALTER TABLE `tblproject`
  ADD CONSTRAINT `ProjectDistrict_FK` FOREIGN KEY (`DistrictID`) REFERENCES `tbldistrict` (`DistrictID`);

--
-- Constraints for table `tblquotation`
--
ALTER TABLE `tblquotation`
  ADD CONSTRAINT `QuotationClient_FK` FOREIGN KEY (`ClientID`) REFERENCES `tblclient` (`ClientID`),
  ADD CONSTRAINT `QuotationRequisition_FK` FOREIGN KEY (`RequisitionID`) REFERENCES `tblrequisition` (`RequisitionID`);

--
-- Constraints for table `tblrequisition`
--
ALTER TABLE `tblrequisition`
  ADD CONSTRAINT `RequisitionBudget_FK` FOREIGN KEY (`BudgetID`) REFERENCES `tblbudget` (`BudgetID`),
  ADD CONSTRAINT `RequisitionStatus_FK` FOREIGN KEY (`StatusID`) REFERENCES `tblstatus` (`StatusID`),
  ADD CONSTRAINT `RevenueTypeRequisition_FK` FOREIGN KEY (`RevenueTypeID`) REFERENCES `tblrevenuetype` (`RevenueTypeID`);

--
-- Constraints for table `tblrequisitionapproval`
--
ALTER TABLE `tblrequisitionapproval`
  ADD CONSTRAINT `RequisitionApprovalDecision_FK` FOREIGN KEY (`DecisionID`) REFERENCES `tbldecision` (`DecisionID`),
  ADD CONSTRAINT `RequisitionApproval_FK` FOREIGN KEY (`RequisitionID`) REFERENCES `tblrequisition` (`RequisitionID`);

--
-- Constraints for table `tblrevenue`
--
ALTER TABLE `tblrevenue`
  ADD CONSTRAINT `RevenueRevenueType_FK` FOREIGN KEY (`RevenueTypeID`) REFERENCES `tblrevenuetype` (`RevenueTypeID`);

--
-- Constraints for table `tblrevenuedetail`
--
ALTER TABLE `tblrevenuedetail`
  ADD CONSTRAINT `BudgetRevenue_FK` FOREIGN KEY (`BudgetID`) REFERENCES `tblbudget` (`BudgetID`),
  ADD CONSTRAINT `RevenueDatailRevenue_FK` FOREIGN KEY (`RevenueID`) REFERENCES `tblrevenue` (`RevenueID`);

--
-- Constraints for table `tblsector`
--
ALTER TABLE `tblsector`
  ADD CONSTRAINT `SectorDistrict_FK` FOREIGN KEY (`DistrictID`) REFERENCES `tbldistrict` (`DistrictID`);

--
-- Constraints for table `tblsubmission`
--
ALTER TABLE `tblsubmission`
  ADD CONSTRAINT `BudgetSubmission_FK` FOREIGN KEY (`BudgetID`) REFERENCES `tblbudget` (`BudgetID`),
  ADD CONSTRAINT `DDAMeetingSubmission_FK` FOREIGN KEY (`DDAMeetingID`) REFERENCES `tblddameeting` (`DDAMeetingID`),
  ADD CONSTRAINT `RevenueTypeSubmission_FK` FOREIGN KEY (`RevenueTypeID`) REFERENCES `tblrevenuetype` (`RevenueTypeID`),
  ADD CONSTRAINT `SubmissionStatus_FK` FOREIGN KEY (`StatusID`) REFERENCES `tblstatus` (`StatusID`);

--
-- Constraints for table `tblsubmissionapproval`
--
ALTER TABLE `tblsubmissionapproval`
  ADD CONSTRAINT `SubmissionApprovalDecision_FK` FOREIGN KEY (`DecisionID`) REFERENCES `tbldecision` (`DecisionID`),
  ADD CONSTRAINT `SubmissionApproval_FK` FOREIGN KEY (`SubmissionID`) REFERENCES `tblsubmission` (`SubmissionID`);

--
-- Constraints for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD CONSTRAINT `DistrictUser_FK` FOREIGN KEY (`DistrictID`) REFERENCES `tbldistrict` (`DistrictID`),
  ADD CONSTRAINT `FYearUser_FK` FOREIGN KEY (`FYID`) REFERENCES `tblfinancialyear` (`FYID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
